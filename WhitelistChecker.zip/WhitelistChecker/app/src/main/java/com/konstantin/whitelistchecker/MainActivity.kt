package com.konstantin.whitelistchecker

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.View
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

// Домены, которые точно есть в белом списке Минцифры (доступны при ограничениях)
val WHITELIST_DOMAINS = listOf(
    "max.ru",
    "vk.ru",
    "vkvideo.ru",
    "yandex.ru",
    "ozon.ru",
    "sber.ru",
    "tbank.ru"
)

// Домены вне белого списка — должны быть недоступны при активной фильтрации
val NON_WHITELIST_DOMAINS = listOf(
    "smolanin.ru",
    "tiktok.com",
    "smoladmin.ru",
    "transphoto.org",
    "muttp.ru",
    "microsoft.com"
)

// status: "ok" — получили ответ; "reset" — соединение установилось, потом оборвано (характерно для ТСПУ);
// "timeout" — вообще нет ответа
data class CheckResult(val domain: String, val reachable: Boolean, val status: String)

class MainActivity : AppCompatActivity() {

    private lateinit var statusIndicator: View
    private lateinit var statusText: TextView
    private lateinit var detailsText: TextView
    private lateinit var checkButton: Button
    private lateinit var connectivityManager: ConnectivityManager
    private val executor: ExecutorService = Executors.newFixedThreadPool(8)

    // Мобильная сеть, которую мы вынуждаем использовать вместо Wi-Fi
    private var cellularNetwork: Network? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusIndicator = findViewById(R.id.statusIndicator)
        statusText = findViewById(R.id.statusText)
        detailsText = findViewById(R.id.detailsText)
        checkButton = findViewById(R.id.checkButton)
        connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager

        checkButton.setOnClickListener { requestCellularAndRun() }
    }

    // Запрашиваем именно мобильную сеть, чтобы не уйти в Wi-Fi
    private fun requestCellularAndRun() {
        statusText.text = "Ищу мобильную сеть..."
        statusIndicator.setBackgroundColor(0xFF808080.toInt())
        detailsText.text = ""

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()

        // timeoutMs = 5000: если за 5 сек сотовая сеть не найдена — почти наверняка
        // выключены мобильные данные, а не проблема с сайтами
        connectivityManager.requestNetwork(request, object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cellularNetwork = network
                runOnUiThread { runChecks(network) }
            }

            override fun onUnavailable() {
                runOnUiThread {
                    statusText.text = "Включи мобильный интернет (мобильные данные выключены)"
                    statusIndicator.setBackgroundColor(0xFF808080.toInt())
                }
            }
        }, 5000)
    }

    private fun runChecks(network: Network) {
        statusText.text = "Проверяю..."

        executor.submit {
            val whitelistResults = WHITELIST_DOMAINS.map { checkDomain(network, it) }
            val nonWhitelistResults = NON_WHITELIST_DOMAINS.map { checkDomain(network, it) }

            val whitelistReachable = whitelistResults.count { it.reachable }
            val nonWhitelistReachable = nonWhitelistResults.count { it.reachable }

            runOnUiThread {
                applyVerdict(whitelistReachable, nonWhitelistReachable, whitelistResults, nonWhitelistResults)
            }
        }
    }

    // Одна проверка: реальное TCP/TLS-соединение и HTTP-ответ, а не ICMP-пинг.
    // Таймауты увеличены до 9 сек — ТСПУ при блокировке часто пропускает
    // первые пакеты (~16КБ) и рвёт соединение через 5-7 сек, а не сразу.
    private fun checkDomain(network: Network, domain: String): CheckResult {
        return try {
            val url = URL("https://$domain")
            val connection = network.openConnection(url) as HttpURLConnection
            connection.connectTimeout = 9000
            connection.readTimeout = 9000
            connection.instanceFollowRedirects = true
            connection.requestMethod = "HEAD"
            val code = connection.responseCode
            connection.disconnect()
            CheckResult(domain, true, "ok")
        } catch (e: java.net.SocketException) {
            // Соединение было установлено и потом сброшено — характерная подпись
            // блокировки через ТСПУ, а не просто "сайт недоступен"
            val isReset = e.message?.contains("reset", ignoreCase = true) == true
            CheckResult(domain, false, if (isReset) "reset" else "timeout")
        } catch (e: java.net.SocketTimeoutException) {
            CheckResult(domain, false, "timeout")
        } catch (e: Exception) {
            CheckResult(domain, false, "timeout")
        }
    }

    private fun applyVerdict(
        whitelistReachable: Int,
        nonWhitelistReachable: Int,
        whitelistResults: List<CheckResult>,
        nonWhitelistResults: List<CheckResult>
    ) {
        val details = StringBuilder()
        details.append("Белый список (доступно $whitelistReachable из ${WHITELIST_DOMAINS.size}):\n")
        whitelistResults.forEach { details.append("  ${statusLabel(it)} ${it.domain}\n") }
        details.append("\nВне списка (доступно $nonWhitelistReachable из ${NON_WHITELIST_DOMAINS.size}):\n")
        nonWhitelistResults.forEach { details.append("  ${statusLabel(it)} ${it.domain}\n") }
        detailsText.text = details.toString()

        when {
            whitelistReachable == 0 && nonWhitelistReachable == 0 -> {
                // Ничего не отвечает — либо нет интернета вообще, либо тотальная блокировка
                statusIndicator.setBackgroundColor(0xFF000000.toInt())
                statusText.text = "Интернета нет вообще"
            }
            whitelistReachable > nonWhitelistReachable -> {
                // Белые сайты отвечают заметно лучше обычных — похоже на фильтрацию
                statusIndicator.setBackgroundColor(0xFFFF0000.toInt())
                statusText.text = "Похоже, белый список включён"
            }
            else -> {
                // Всё примерно одинаково доступно — ограничений нет
                statusIndicator.setBackgroundColor(0xFF00C853.toInt())
                statusText.text = "Ограничений не обнаружено"
            }
        }
    }

    private fun statusLabel(r: CheckResult): String = when (r.status) {
        "ok" -> "OK    "
        "reset" -> "RESET " // соединение оборвано после установления — похоже на ТСПУ
        else -> "--    "    // нет ответа вообще
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}
