package com.konstantin.whitelistchecker

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.os.Bundle
import android.os.Process
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.WindowCompat
import androidx.drawerlayout.widget.DrawerLayout
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

// Домены, которые точно есть в белом списке Минцифры (доступны при ограничениях)
val WHITELIST_DOMAINS = listOf(
    "max.ru",
    "vk.ru",
    "vkvideo.ru",
    "yandex.ru",
    "ozon.ru",
    "sber.ru",
    "tbank.ru",
    "kremlin.ru",
    "vtb.ru",
    "dzen.ru"
)

// Домены вне белого списка — должны быть недоступны при активной фильтрации
val NON_WHITELIST_DOMAINS = listOf(
    "tiktok.com",
    "smoladmin.ru",
    "transphoto.org",
    "muttp.ru",
    "microsoft.com",
    "oppo.com",
    "wikipedia.org",
    "fandom.com",
    "weather.com",
    "twitch.tv"
)

// Сайт разработчика — проверяется отдельно и показывается своей строкой внизу,
// а не в общем списке "вне списка"
const val DEVELOPER_SITE = "smolanin.ru"

// status: "ok" — получили ответ; "reset" — соединение установилось, потом оборвано (характерно для ТСПУ);
// "timeout" — вообще нет ответа
data class CheckResult(val domain: String, val reachable: Boolean, val status: String)

class MainActivity : AppCompatActivity() {

    private lateinit var statusBox: LinearLayout
    private lateinit var statusWord: TextView
    private lateinit var progressSpinner: ProgressBar
    private lateinit var whitelistColumn: TextView
    private lateinit var nonWhitelistColumn: TextView
    private lateinit var trafficText: TextView
    private lateinit var developerSiteText: TextView
    private lateinit var connectivityManager: ConnectivityManager
    private val executor: ExecutorService = Executors.newFixedThreadPool(8)

    // Мобильная сеть, которую мы вынуждаем использовать вместо Wi-Fi
    private var cellularNetwork: Network? = null

    // Цвета для каждого статуса прямоугольника
    private val COLOR_CHECKING = 0xFFB0B0B0.toInt()  // сероватый — идёт проверка
    private val COLOR_ON = 0xFFE53935.toInt()        // красный — белый список включён
    private val COLOR_OFF = 0xFF43A047.toInt()       // зелёный — ограничений нет
    private val COLOR_NO_NETWORK = 0xFF000000.toInt() // чёрный — нет доступа к сети
    private val COLOR_VPN = 0xFFFF9800.toInt()       // оранжевый — отдельный случай, включён VPN

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Android 15+ по умолчанию рисует контент под системными панелями
        // (edge-to-edge), из-за чего верхняя панель (время, батарея, сеть)
        // становится прозрачной и сливается с приложением. Возвращаем
        // классическое поведение — контент не залезает под панель, и красим
        // саму панель серым, чтобы она была явно отделена
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = 0xFF808080.toInt()

        // Ловим любые необработанные ошибки (в том числе в фоновом потоке проверки)
        // и показываем текст перед крашем, вместо тихого вылета
        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            runOnUiThread {
                android.widget.Toast.makeText(
                    this,
                    "Краш: ${throwable.javaClass.simpleName}: ${throwable.message}",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            Thread.sleep(3000) // даём тосту время показаться до закрытия процесса
            android.os.Process.killProcess(android.os.Process.myPid())
        }

        statusBox = findViewById(R.id.statusBox)
        statusWord = findViewById(R.id.statusWord)
        progressSpinner = findViewById(R.id.progressSpinner)
        whitelistColumn = findViewById(R.id.whitelistColumn)
        nonWhitelistColumn = findViewById(R.id.nonWhitelistColumn)
        trafficText = findViewById(R.id.trafficText)
        developerSiteText = findViewById(R.id.developerSiteText)
        connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager

        val drawerLayout: DrawerLayout = findViewById(R.id.drawerLayout)
        val settingsGear: TextView = findViewById(R.id.settingsGear)
        settingsGear.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        statusBox.setOnClickListener {
            try {
                if (isVpnActive()) {
                    setStatus(COLOR_VPN, "Выключи VPN")
                    whitelistColumn.text = ""
                    nonWhitelistColumn.text = ""
                    developerSiteText.text = ""
                    trafficText.visibility = android.view.View.GONE
                } else {
                    requestCellularAndRun()
                }
            } catch (e: Exception) {
                setStatus(COLOR_NO_NETWORK, "Ошибка: ${e.javaClass.simpleName}")
            }
        }
    }

    // Единая точка обновления прямоугольника статуса: цвет фона, текст,
    // и крутилка — крутилка видна только пока идёт сама проверка
    private fun setStatus(color: Int, word: String, showSpinner: Boolean = false) {
        statusBox.setBackgroundColor(color)
        statusWord.text = word
        progressSpinner.visibility = if (showSpinner) android.view.View.VISIBLE else android.view.View.GONE
    }

    // Проверяем, есть ли среди активных сетей хоть одна с транспортом VPN.
    // Если VPN включён с блокировкой "трафик только через VPN" — прямые
    // соединения в обход VPN будут рубиться системой, и проверка даст
    // ложный результат "нет доступа к сети"
    private fun isVpnActive(): Boolean {
        connectivityManager.allNetworks.forEach { network ->
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            if (capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) {
                return true
            }
        }
        return false
    }

    // Запрашиваем именно мобильную сеть, чтобы не уйти в Wi-Fi
    private fun requestCellularAndRun() {
        setStatus(COLOR_CHECKING, "Проверка", showSpinner = true)
        whitelistColumn.text = ""
        nonWhitelistColumn.text = ""
        developerSiteText.text = ""
        trafficText.visibility = android.view.View.GONE
        cellularNetwork = null

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cellularNetwork = network
                runOnUiThread { runChecks(network) }
            }

            override fun onUnavailable() {
                runOnUiThread {
                    setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
                }
            }
        }

        // Используем двухаргументную версию requestNetwork — она доступна с API 21,
        // в отличие от версии с таймаутом (нужен API 26+), которая на старых
        // Android вызывала бы NoSuchMethodError и мгновенный краш
        connectivityManager.requestNetwork(request, callback)

        // Таймаут делаем вручную: если за 5 сек onAvailable не сработал — считаем,
        // что мобильных данных нет
        android.os.Handler(mainLooper).postDelayed({
            if (cellularNetwork == null) {
                setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
            }
        }, 5000)
    }

    private fun runChecks(network: Network) {
        setStatus(COLOR_CHECKING, "Проверка", showSpinner = true)

        executor.submit {
            // Замеряем трафик всего приложения до и после — сама проверка ничего
            // больше по сети не делает, так что разница — это и есть её стоимость
            val uid = Process.myUid()
            val rxBefore = TrafficStats.getUidRxBytes(uid)
            val txBefore = TrafficStats.getUidTxBytes(uid)

            val whitelistResults = WHITELIST_DOMAINS.map { checkDomain(network, it) }
            val nonWhitelistResults = NON_WHITELIST_DOMAINS.map { checkDomain(network, it) }
            val developerSiteResult = checkDomain(network, DEVELOPER_SITE)

            val rxAfter = TrafficStats.getUidRxBytes(uid)
            val txAfter = TrafficStats.getUidTxBytes(uid)

            val whitelistReachable = whitelistResults.count { it.reachable }
            val nonWhitelistReachable = nonWhitelistResults.count { it.reachable }

            // TrafficStats возвращает -1, если счётчик недоступен на этом устройстве —
            // тогда просто не показываем плашку, а не врём про 0 КБ
            val trafficBytes: Long? = if (rxBefore < 0 || txBefore < 0 || rxAfter < 0 || txAfter < 0) {
                null
            } else {
                (rxAfter - rxBefore) + (txAfter - txBefore)
            }

            runOnUiThread {
                applyVerdict(whitelistReachable, nonWhitelistReachable, whitelistResults, nonWhitelistResults, trafficBytes, developerSiteResult)
            }
        }
    }

    // Одна проверка: реальное TCP/TLS-соединение и HTTP-ответ, а не ICMP-пинг.
    // Таймауты увеличены до 9 сек — ТСПУ при блокировке часто пропускает
    // первые пакеты (~16КБ) и рвёт соединение через 5-7 сек, а не сразу.
    private fun checkDomain(network: Network, domain: String): CheckResult {
        return try {
            val url = URL("https://$domain")
            val connection = network.openConnection(url) as HttpURLConnection
            connection.connectTimeout = 9000
            connection.readTimeout = 9000
            connection.instanceFollowRedirects = true
            connection.requestMethod = "HEAD"
            connection.responseCode
            connection.disconnect()
            CheckResult(domain, true, "ok")
        } catch (e: java.net.SocketException) {
            // Соединение было установлено и потом сброшено — характерная подпись
            // блокировки через ТСПУ, а не просто "сайт недоступен"
            val isReset = e.message?.contains("reset", ignoreCase = true) == true
            CheckResult(domain, false, if (isReset) "reset" else "timeout")
        } catch (e: java.net.SocketTimeoutException) {
            CheckResult(domain, false, "timeout")
        } catch (e: Exception) {
            CheckResult(domain, false, "timeout")
        }
    }

    private fun applyVerdict(
        whitelistReachable: Int,
        nonWhitelistReachable: Int,
        whitelistResults: List<CheckResult>,
        nonWhitelistResults: List<CheckResult>,
        trafficBytes: Long?,
        developerSiteResult: CheckResult
    ) {
        val whitelistDetails = StringBuilder()
        whitelistDetails.append("($whitelistReachable из ${WHITELIST_DOMAINS.size})\n")
        whitelistResults.forEach { whitelistDetails.append("${statusLabel(it)} ${it.domain}\n") }
        whitelistColumn.text = whitelistDetails.toString()

        val nonWhitelistDetails = StringBuilder()
        nonWhitelistDetails.append("($nonWhitelistReachable из ${NON_WHITELIST_DOMAINS.size})\n")
        nonWhitelistResults.forEach { nonWhitelistDetails.append("${statusLabel(it)} ${it.domain}\n") }
        nonWhitelistColumn.text = nonWhitelistDetails.toString()

        developerSiteText.text = "Сайт разработчика\n${developerSiteResult.domain} ${if (developerSiteResult.reachable) "доступен" else "недоступен"}"

        if (trafficBytes != null) {
            val kb = trafficBytes / 1024.0
            trafficText.text = if (kb < 1024) {
                "Потрачено трафика: ${"%.1f".format(kb)} КБ"
            } else {
                "Потрачено трафика: ${"%.2f".format(kb / 1024.0)} МБ"
            }
            trafficText.visibility = android.view.View.VISIBLE
        } else {
            trafficText.visibility = android.view.View.GONE
        }

        when {
            whitelistReachable == 0 && nonWhitelistReachable == 0 -> {
                // Ничего не отвечает — либо нет интернета вообще, либо тотальная блокировка
                setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
            }
            whitelistReachable > nonWhitelistReachable -> {
                // Белые сайты отвечают заметно лучше обычных — похоже на фильтрацию
                setStatus(COLOR_ON, "Включены")
            }
            else -> {
                // Всё примерно одинаково доступно — ограничений нет
                setStatus(COLOR_OFF, "Выключены")
            }
        }
    }

    private fun statusLabel(r: CheckResult): String = when (r.status) {
        "ok" -> "OK    "
        "reset" -> "RESET " // соединение оборвано после установления — похоже на ТСПУ
        else -> "--    "    // нет ответа вообще
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}
