package com.konstantin.whitelistchecker

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    // Белые сайты
    private val whitelistSites = listOf(
        "kremlin.ru",
        "vtb.ru",
        "dzen.ru"
    )

    // Небелые сайты
    private val nonWhitelistSites = listOf(
        "oppo.com",
        "wikipedia.org",
        "fandom.com",
        "weather.com",
        "twitch.tv"
    )

    // Сайт разработчика
    private val devSite = "smolanin.ru"

    private lateinit var statusTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusTextView = findViewById(R.id.statusTextView)

        // Запуск проверки статусов в фоне
        CoroutineScope(Dispatchers.IO).launch {
            val whiteResults = checkSites(whitelistSites)
            val nonWhiteResults = checkSites(nonWhitelistSites)
            val devResult = checkSingleSite(devSite)

            withContext(Dispatchers.Main) {
                renderResults(whiteResults, nonWhiteResults, devResult)
            }
        }
    }

    private suspend fun checkSites(sites: List<String>): Map<String, Boolean> {
        return sites.associateWith { site -> checkSingleSite(site) }
    }

    private fun checkSingleSite(site: String): Boolean {
        return try {
            val url = URL("https://$site")
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 3000
            connection.readTimeout = 3000
            connection.requestMethod = "HEAD"
            val responseCode = connection.responseCode
            responseCode in 200..399
        } catch (e: Exception) {
            false
        }
    }

    private fun renderResults(
        white: Map<String, Boolean>,
        nonWhite: Map<String, Boolean>,
        devAvailable: Boolean
    ) {
        val sb = StringBuilder()

        sb.append("=== БЕЛЫЕ СПИСКИ ===\n")
        white.forEach { (site, available) ->
            sb.append("$site: ${if (available) "доступен" else "недоступен"}\n")
        }

        sb.append("\n=== НЕБЕЛЫЕ СПИСКИ ===\n")
        nonWhite.forEach { (site, available) ->
            sb.append("$site: ${if (available) "доступен" else "недоступен"}\n")
        }

        sb.append("\n-------------------\n")
        sb.append("Сайт разработчика\n")
        sb.append("$devSite \"${if (devAvailable) "доступен" else "недоступен"}\"")

        statusTextView.text = sb.toString()
    }
}
