# WhitelistChecker
Android project with network check logic.