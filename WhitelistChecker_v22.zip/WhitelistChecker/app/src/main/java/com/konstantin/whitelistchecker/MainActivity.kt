package com.konstantin.whitelistchecker

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.WindowCompat
import androidx.drawerlayout.widget.DrawerLayout
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

// Домены, которые точно есть в белом списке Минцифры (доступны при ограничениях)
val WHITELIST_DOMAINS = listOf(
    "max.ru",
    "vk.ru",
    "vkvideo.ru",
    "yandex.ru",
    "ozon.ru",
    "sber.ru",
    "tbank.ru",
    "kremlin.ru",
    "vtb.ru",
    "dzen.ru"
)

// Домены вне белого списка — должны быть недоступны при активной фильтрации
val NON_WHITELIST_DOMAINS = listOf(
    "tiktok.com",
    "smoladmin.ru",
    "transphoto.org",
    "muttp.ru",
    "microsoft.com",
    "oppo.com",
    "wikipedia.org",
    "fandom.com",
    "weather.com",
    "twitch.tv"
)

// Сайт разработчика — проверяется отдельно, показывается своей строкой внизу
const val DEVELOPER_SITE = "smolanin.ru"

// status: "ok" — получили ответ; "reset" — соединение установилось, потом оборвано (характерно для ТСПУ);
// "timeout" — вообще нет ответа
data class CheckResult(val domain: String, val reachable: Boolean, val status: String)

class MainActivity : AppCompatActivity() {

    private lateinit var statusBox: LinearLayout
    private lateinit var statusWord: TextView
    private lateinit var progressSpinner: ProgressBar
    private lateinit var whitelistColumnContainer: LinearLayout
    private lateinit var nonWhitelistColumnContainer: LinearLayout
    private lateinit var sitesContainer: LinearLayout
    private lateinit var collapseToggle: TextView
    private lateinit var trafficText: TextView
    private lateinit var timeText: TextView
    private lateinit var developerSiteContainer: LinearLayout
    private lateinit var connectivityManager: ConnectivityManager

    // Пул на 8 параллельных проверок — вместо последовательного обхода всех
    // доменов один за другим (это раньше и давало 30-40 сек)
    private val executor: ExecutorService = Executors.newFixedThreadPool(8)

    private var cellularNetwork: Network? = null
    private var isChecking = false

    // Цвета для каждого статуса прямоугольника
    private val COLOR_CHECKING = 0xFFB0B0B0.toInt()
    private val COLOR_ON = 0xFFE53935.toInt()
    private val COLOR_OFF = 0xFF43A047.toInt()
    private val COLOR_NO_NETWORK = 0xFF000000.toInt()
    private val COLOR_VPN = 0xFFFF9800.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Классическое поведение системных панелей: контент не залезает под них
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = 0xFF2A2A2A.toInt()

        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            runOnUiThread {
                android.widget.Toast.makeText(
                    this,
                    "Краш: ${throwable.javaClass.simpleName}: ${throwable.message}",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            Thread.sleep(3000)
            Process.killProcess(Process.myPid())
        }

        statusBox = findViewById(R.id.statusBox)
        statusWord = findViewById(R.id.statusWord)
        progressSpinner = findViewById(R.id.progressSpinner)
        whitelistColumnContainer = findViewById(R.id.whitelistColumnContainer)
        nonWhitelistColumnContainer = findViewById(R.id.nonWhitelistColumnContainer)
        sitesContainer = findViewById(R.id.sitesContainer)
        collapseToggle = findViewById(R.id.collapseToggle)
        trafficText = findViewById(R.id.trafficText)
        timeText = findViewById(R.id.timeText)
        developerSiteContainer = findViewById(R.id.developerSiteContainer)
        connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager

        val drawerLayout: DrawerLayout = findViewById(R.id.drawerLayout)
        val menuButton: TextView = findViewById(R.id.menuButton)
        menuButton.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        collapseToggle.setOnClickListener {
            if (sitesContainer.visibility == View.VISIBLE) {
                sitesContainer.visibility = View.GONE
                collapseToggle.text = "▶"
            } else {
                sitesContainer.visibility = View.VISIBLE
                collapseToggle.text = "▼"
            }
        }

        statusBox.setOnClickListener {
            if (isChecking) return@setOnClickListener
            try {
                if (isVpnActive()) {
                    setStatus(COLOR_VPN, "Выключи VPN")
                    whitelistColumnContainer.removeAllViews()
                    nonWhitelistColumnContainer.removeAllViews()
                    developerSiteContainer.removeAllViews()
                    trafficText.visibility = View.GONE
                    timeText.visibility = View.GONE
                } else {
                    requestCellularAndRun()
                }
            } catch (e: Exception) {
                setStatus(COLOR_NO_NETWORK, "Ошибка: ${e.javaClass.simpleName}")
            }
        }
    }

    private fun setStatus(color: Int, word: String, showSpinner: Boolean = false) {
        statusBox.setBackgroundColor(color)
        statusWord.text = word
        progressSpinner.visibility = if (showSpinner) View.VISIBLE else View.GONE
    }

    private fun isVpnActive(): Boolean {
        connectivityManager.allNetworks.forEach { network ->
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            if (capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) {
                return true
            }
        }
        return false
    }

    private fun requestCellularAndRun() {
        isChecking = true
        setStatus(COLOR_CHECKING, "Проверка", showSpinner = true)
        trafficText.visibility = View.GONE
        timeText.visibility = View.GONE
        developerSiteContainer.removeAllViews()
        cellularNetwork = null

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cellularNetwork = network
                runOnUiThread { runChecks(network) }
            }

            override fun onUnavailable() {
                runOnUiThread {
                    isChecking = false
                    setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
                }
            }
        }

        connectivityManager.requestNetwork(request, callback)

        android.os.Handler(mainLooper).postDelayed({
            if (cellularNetwork == null) {
                isChecking = false
                setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
            }
        }, 5000)
    }

    // Создаёт строку "спиннер + домен" в колонке и возвращает ссылки на вьюхи,
    // чтобы потом обновить именно эту строку, не трогая остальные
    private fun createDomainRow(domain: String, container: LinearLayout): Pair<TextView, ProgressBar> {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val spinner = ProgressBar(this, null, android.R.attr.progressBarStyleSmall)
        val spinnerParams = LinearLayout.LayoutParams(dp(14), dp(14))
        spinnerParams.marginEnd = dp(6)
        spinner.layoutParams = spinnerParams

        val label = TextView(this)
        label.text = domain
        label.textSize = 12f
        label.setTextColor(0xFFEEEEEE.toInt())
        label.typeface = android.graphics.Typeface.MONOSPACE

        row.addView(spinner)
        row.addView(label)
        container.addView(row)

        return Pair(label, spinner)
    }

    private fun updateRow(row: Pair<TextView, ProgressBar>, result: CheckResult) {
        row.second.visibility = View.GONE
        row.first.text = "${statusLabel(result)} ${result.domain}"
    }

    private fun runChecks(network: Network) {
        setStatus(COLOR_CHECKING, "Проверка", showSpinner = true)
        whitelistColumnContainer.removeAllViews()
        nonWhitelistColumnContainer.removeAllViews()

        val whitelistRows = WHITELIST_DOMAINS.associateWith { createDomainRow(it, whitelistColumnContainer) }
        val nonWhitelistRows = NON_WHITELIST_DOMAINS.associateWith { createDomainRow(it, nonWhitelistColumnContainer) }
        developerSiteContainer.removeAllViews()
        val developerRow = createDomainRow(DEVELOPER_SITE, developerSiteContainer)

        val startTime = System.currentTimeMillis()
        val uid = Process.myUid()
        val rxBefore = TrafficStats.getUidRxBytes(uid)
        val txBefore = TrafficStats.getUidTxBytes(uid)

        val totalTasks = WHITELIST_DOMAINS.size + NON_WHITELIST_DOMAINS.size + 1
        val completedCount = AtomicInteger(0)
        val whitelistResultsMap = ConcurrentHashMap<String, CheckResult>()
        val nonWhitelistResultsMap = ConcurrentHashMap<String, CheckResult>()
        val developerResultHolder = ConcurrentHashMap<String, CheckResult>()

        fun maybeFinish() {
            if (completedCount.incrementAndGet() == totalTasks) {
                val rxAfter = TrafficStats.getUidRxBytes(uid)
                val txAfter = TrafficStats.getUidTxBytes(uid)
                val elapsedMs = System.currentTimeMillis() - startTime

                val trafficBytes: Long? = if (rxBefore < 0 || txBefore < 0 || rxAfter < 0 || txAfter < 0) {
                    null
                } else {
                    (rxAfter - rxBefore) + (txAfter - txBefore)
                }

                val whitelistResults = WHITELIST_DOMAINS.map { whitelistResultsMap[it]!! }
                val nonWhitelistResults = NON_WHITELIST_DOMAINS.map { nonWhitelistResultsMap[it]!! }
                val developerResult = developerResultHolder[DEVELOPER_SITE]!!

                runOnUiThread {
                    isChecking = false
                    finalizeVerdict(whitelistResults, nonWhitelistResults, trafficBytes, elapsedMs, developerResult)
                }
            }
        }

        WHITELIST_DOMAINS.forEach { domain ->
            executor.submit {
                val result = checkDomain(network, domain)
                whitelistResultsMap[domain] = result
                runOnUiThread { updateRow(whitelistRows[domain]!!, result) }
                maybeFinish()
            }
        }

        NON_WHITELIST_DOMAINS.forEach { domain ->
            executor.submit {
                val result = checkDomain(network, domain)
                nonWhitelistResultsMap[domain] = result
                runOnUiThread { updateRow(nonWhitelistRows[domain]!!, result) }
                maybeFinish()
            }
        }

        executor.submit {
            val result = checkDomain(network, DEVELOPER_SITE)
            developerResultHolder[DEVELOPER_SITE] = result
            runOnUiThread { updateRow(developerRow, result) }
            maybeFinish()
        }
    }

    // Одна проверка: реальное TCP/TLS-соединение и HTTP-ответ, а не ICMP-пинг.
    // Таймауты увеличены до 9 сек — ТСПУ при блокировке часто пропускает
    // первые пакеты (~16КБ) и рвёт соединение через 5-7 сек, а не сразу.
    private fun checkDomain(network: Network, domain: String): CheckResult {
        return try {
            val url = URL("https://$domain")
            val connection = network.openConnection(url) as HttpURLConnection
            connection.connectTimeout = 9000
            connection.readTimeout = 9000
            connection.instanceFollowRedirects = true
            connection.requestMethod = "HEAD"
            connection.responseCode
            connection.disconnect()
            CheckResult(domain, true, "ok")
        } catch (e: java.net.SocketException) {
            val isReset = e.message?.contains("reset", ignoreCase = true) == true
            CheckResult(domain, false, if (isReset) "reset" else "timeout")
        } catch (e: java.net.SocketTimeoutException) {
            CheckResult(domain, false, "timeout")
        } catch (e: Exception) {
            CheckResult(domain, false, "timeout")
        }
    }

    private fun finalizeVerdict(
        whitelistResults: List<CheckResult>,
        nonWhitelistResults: List<CheckResult>,
        trafficBytes: Long?,
        elapsedMs: Long,
        developerResult: CheckResult
    ) {
        val whitelistReachable = whitelistResults.count { it.reachable }
        val nonWhitelistReachable = nonWhitelistResults.count { it.reachable }

        if (trafficBytes != null) {
            val kb = trafficBytes / 1024.0
            trafficText.text = if (kb < 1024) {
                "Потрачено трафика: ${"%.1f".format(kb)} КБ"
            } else {
                "Потрачено трафика: ${"%.2f".format(kb / 1024.0)} МБ"
            }
            trafficText.visibility = View.VISIBLE
        } else {
            trafficText.visibility = View.GONE
        }

        timeText.text = "Время проверки: ${"%.1f".format(elapsedMs / 1000.0)} сек"
        timeText.visibility = View.VISIBLE

        when {
            whitelistReachable == 0 && nonWhitelistReachable == 0 -> {
                setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
            }
            whitelistReachable > nonWhitelistReachable -> {
                setStatus(COLOR_ON, "Включены")
            }
            else -> {
                setStatus(COLOR_OFF, "Выключены")
            }
        }
    }

    private fun statusLabel(r: CheckResult): String = when (r.status) {
        "ok" -> "OK   "
        "reset" -> "RESET"
        else -> "--   "
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}
