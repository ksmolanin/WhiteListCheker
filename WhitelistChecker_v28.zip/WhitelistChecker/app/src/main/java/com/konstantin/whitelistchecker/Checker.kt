package com.konstantin.whitelistchecker

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.net.HttpURLConnection
import java.net.URL

// Домены, которые точно есть в белом списке Минцифры (доступны при ограничениях)
val WHITELIST_DOMAINS = listOf(
    "max.ru",
    "vk.ru",
    "vkvideo.ru",
    "yandex.ru",
    "ozon.ru",
    "sber.ru",
    "tbank.ru",
    "gosuslugi.ru",
    "vtb.ru",
    "dzen.ru"
)

// Домены вне белого списка — должны быть недоступны при активной фильтрации
val NON_WHITELIST_DOMAINS = listOf(
    "tiktok.com",
    "smoladmin.ru",
    "transphoto.org",
    "muttp.ru",
    "microsoft.com",
    "oppo.com",
    "wikipedia.org",
    "fandom.com",
    "weather.com",
    "twitch.tv"
)

// Сайт разработчика — проверяется отдельно, показывается своей строкой внизу
const val DEVELOPER_SITE = "smolanin.ru"

// status: "ok" — получили ответ; "reset" — соединение установилось, потом оборвано (характерно для ТСПУ);
// "timeout" — вообще нет ответа
data class CheckResult(val domain: String, val reachable: Boolean, val status: String)

object Checker {

    // Проверяем, есть ли среди активных сетей хоть одна с транспортом VPN.
    // Если VPN включён с блокировкой "трафик только через VPN" — прямые
    // соединения в обход VPN будут рубиться системой, и проверка даст
    // ложный результат
    fun isVpnActive(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.allNetworks.forEach { network ->
            val capabilities = cm.getNetworkCapabilities(network)
            if (capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) {
                return true
            }
        }
        return false
    }

    // Одна проверка: реальное TCP/TLS-соединение и HTTP-ответ, а не ICMP-пинг.
    // По 9 сек на подключение и на ответ — раньше это давало 27-30 сек только
    // из-за медленного kremlin.ru, без него можно спокойно вернуть исходный запас,
    // чтобы не терять точность RESET-детекции на других доменах
    fun checkDomain(network: Network, domain: String): CheckResult {
        return try {
            val url = URL("https://$domain")
            val connection = network.openConnection(url) as HttpURLConnection
            connection.connectTimeout = 9000
            connection.readTimeout = 9000
            connection.instanceFollowRedirects = true
            connection.requestMethod = "HEAD"
            connection.responseCode
            connection.disconnect()
            CheckResult(domain, true, "ok")
        } catch (e: java.net.SocketException) {
            val isReset = e.message?.contains("reset", ignoreCase = true) == true
            CheckResult(domain, false, if (isReset) "reset" else "timeout")
        } catch (e: java.net.SocketTimeoutException) {
            CheckResult(domain, false, "timeout")
        } catch (e: Exception) {
            CheckResult(domain, false, "timeout")
        }
    }

    // "on" — белый список включён (красный), "off" — ограничений нет (зелёный),
    // "unavailable" — вообще ничего не ответило
    fun determineStatus(whitelistResults: List<CheckResult>, nonWhitelistResults: List<CheckResult>): String {
        val whitelistReachable = whitelistResults.count { it.reachable }
        val nonWhitelistReachable = nonWhitelistResults.count { it.reachable }
        return when {
            whitelistReachable == 0 && nonWhitelistReachable == 0 -> "unavailable"
            whitelistReachable > nonWhitelistReachable -> "on"
            else -> "off"
        }
    }

    fun statusLabel(r: CheckResult): String = when (r.status) {
        "ok" -> "OK   "
        "reset" -> "RESET"
        else -> "--   "
    }
}
