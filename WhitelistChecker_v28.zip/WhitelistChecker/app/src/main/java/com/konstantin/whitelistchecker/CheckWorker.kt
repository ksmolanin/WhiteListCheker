package com.konstantin.whitelistchecker

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.Calendar
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class CheckWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    companion object {
        const val CHANNEL_ID = "whitelist_status_channel"
        const val NOTIFICATION_ID = 1

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Статус интернета",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                manager.createNotificationChannel(channel)
            }
        }
    }

    override fun doWork(): Result {
        val context = applicationContext

        // Вне выбранного времени уведомлений — не проверяем вообще, экономим батарею и трафик
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val startHour = SettingsPrefs.getStartHour(context)
        val endHour = SettingsPrefs.getEndHour(context)
        val withinWindow = if (startHour <= endHour) {
            currentHour in startHour until endHour
        } else {
            // окно переходит через полночь, напр. 22:00–6:00
            currentHour >= startHour || currentHour < endHour
        }
        if (!withinWindow) {
            return Result.success()
        }

        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        // Если включён VPN — вообще ничего не проверяем и не уведомляем
        if (Checker.isVpnActive(context)) {
            return Result.success()
        }

        val network = requestCellularNetworkBlocking(connectivityManager) ?: run {
            // Мобильной сети нет вообще — это тоже "недоступен"
            HistoryStore(context).record(0, 0, "unavailable")
            handleResult(context, "unavailable")
            return Result.success()
        }

        val executor = Executors.newFixedThreadPool(8)
        val whitelistResults = WHITELIST_DOMAINS.map { executor.submit<CheckResult> { Checker.checkDomain(network, it) } }
            .map { it.get() }
        val nonWhitelistResults = NON_WHITELIST_DOMAINS.map { executor.submit<CheckResult> { Checker.checkDomain(network, it) } }
            .map { it.get() }
        executor.shutdown()

        val verdict = Checker.determineStatus(whitelistResults, nonWhitelistResults)
        HistoryStore(context).record(
            whitelistResults.count { it.reachable },
            nonWhitelistResults.count { it.reachable },
            verdict
        )
        handleResult(context, verdict)

        return Result.success()
    }

    // Блокирующий запрос мобильной сети — Worker выполняется в фоновом потоке,
    // так что блокировка здесь не подвешивает интерфейс приложения
    private fun requestCellularNetworkBlocking(connectivityManager: ConnectivityManager): Network? {
        val latch = CountDownLatch(1)
        var result: Network? = null

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                result = network
                latch.countDown()
            }

            override fun onUnavailable() {
                latch.countDown()
            }
        }

        connectivityManager.requestNetwork(request, callback)
        latch.await(8, TimeUnit.SECONDS)
        connectivityManager.unregisterNetworkCallback(callback)
        return result
    }

    private fun handleResult(context: Context, verdict: String) {
        val previousStatus = SettingsPrefs.getLastStatus(context)
        SettingsPrefs.setLastStatus(context, verdict)

        // Уведомляем только при реальном изменении статуса, не каждый раз
        if (previousStatus != null && previousStatus == verdict) {
            return
        }

        val text = when (verdict) {
            "on" -> "Интернет: белый"
            "off" -> "Интернет: полный"
            else -> "Интернет: недоступен"
        }

        ensureChannel(context)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ActivityCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Whitelist Checker")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }
}
