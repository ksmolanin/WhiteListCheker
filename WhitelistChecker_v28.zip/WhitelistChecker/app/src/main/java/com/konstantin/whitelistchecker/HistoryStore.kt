package com.konstantin.whitelistchecker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class HistoryRecord(
    val timestamp: Long,
    val whitelistReachable: Int,
    val nonWhitelistReachable: Int,
    val status: String // "on" / "off" / "unavailable"
)

class HistoryStore(context: Context) : SQLiteOpenHelper(context, "history.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                whitelist_reachable INTEGER NOT NULL,
                nonwhitelist_reachable INTEGER NOT NULL,
                status TEXT NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS history")
        onCreate(db)
    }

    fun record(whitelistReachable: Int, nonWhitelistReachable: Int, status: String) {
        val values = ContentValues().apply {
            put("timestamp", System.currentTimeMillis())
            put("whitelist_reachable", whitelistReachable)
            put("nonwhitelist_reachable", nonWhitelistReachable)
            put("status", status)
        }
        writableDatabase.insert("history", null, values)
        // Не даём базе расти бесконечно — храним только последние 45 дней
        val cutoff = System.currentTimeMillis() - 45L * 24 * 60 * 60 * 1000
        writableDatabase.delete("history", "timestamp < ?", arrayOf(cutoff.toString()))
    }

    fun getRecordsBetween(startMillis: Long, endMillis: Long): List<HistoryRecord> {
        val results = mutableListOf<HistoryRecord>()
        val cursor = readableDatabase.rawQuery(
            "SELECT timestamp, whitelist_reachable, nonwhitelist_reachable, status FROM history " +
                "WHERE timestamp >= ? AND timestamp < ? ORDER BY timestamp ASC",
            arrayOf(startMillis.toString(), endMillis.toString())
        )
        cursor.use {
            while (it.moveToNext()) {
                results.add(
                    HistoryRecord(
                        timestamp = it.getLong(0),
                        whitelistReachable = it.getInt(1),
                        nonWhitelistReachable = it.getInt(2),
                        status = it.getString(3)
                    )
                )
            }
        }
        return results
    }
}
