package com.konstantin.whitelistchecker

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Process
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.core.view.WindowCompat
import androidx.drawerlayout.widget.DrawerLayout
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {

    private lateinit var statusBox: LinearLayout
    private lateinit var statusBoxBg: GradientDrawable
    private lateinit var statusWord: TextView
    private lateinit var progressSpinner: ProgressBar
    private lateinit var whitelistColumnContainer: LinearLayout
    private lateinit var nonWhitelistColumnContainer: LinearLayout
    private lateinit var sitesContainer: LinearLayout
    private lateinit var collapseToggle: TextView
    private lateinit var trafficText: TextView
    private lateinit var timeText: TextView
    private lateinit var developerSiteLink: TextView
    private lateinit var developerSiteStatus: TextView
    private lateinit var developerSiteSpinner: ProgressBar
    private lateinit var connectivityManager: ConnectivityManager

    private lateinit var whitelistRows: Map<String, Pair<TextView, ProgressBar>>
    private lateinit var nonWhitelistRows: Map<String, Pair<TextView, ProgressBar>>

    private val executor: ExecutorService = Executors.newFixedThreadPool(8)
    private val uiHandler = Handler(android.os.Looper.getMainLooper())

    private var cellularNetwork: Network? = null
    private var isChecking = false
    private var currentStatusColor = 0xFFB0B0B0.toInt()
    private var sitesExpanded = false
    private var trafficPulseAnimator: ValueAnimator? = null
    private var timeTicker: Runnable? = null

    private val COLOR_CHECKING = 0xFFB0B0B0.toInt()
    private val COLOR_ON = 0xFFE53935.toInt()
    private val COLOR_OFF = 0xFF43A047.toInt()
    private val COLOR_NO_NETWORK = 0xFF000000.toInt()
    private val COLOR_VPN = 0xFFFF9800.toInt()

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = 0xFF2A2A2A.toInt()

        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            runOnUiThread {
                android.widget.Toast.makeText(
                    this,
                    "Краш: ${throwable.javaClass.simpleName}: ${throwable.message}",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            Thread.sleep(3000)
            Process.killProcess(Process.myPid())
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        CheckWorker.ensureChannel(this)

        statusBox = findViewById(R.id.statusBox)
        statusWord = findViewById(R.id.statusWord)
        progressSpinner = findViewById(R.id.progressSpinner)
        whitelistColumnContainer = findViewById(R.id.whitelistColumnContainer)
        nonWhitelistColumnContainer = findViewById(R.id.nonWhitelistColumnContainer)
        sitesContainer = findViewById(R.id.sitesContainer)
        collapseToggle = findViewById(R.id.collapseToggle)
        trafficText = findViewById(R.id.trafficText)
        timeText = findViewById(R.id.timeText)
        developerSiteLink = findViewById(R.id.developerSiteLink)
        developerSiteStatus = findViewById(R.id.developerSiteStatus)
        developerSiteSpinner = findViewById(R.id.developerSiteSpinner)
        connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager

        // Скруглённый прямоугольник вместо плоского фона — цвет меняем через
        // этот же drawable, чтобы скругление никогда не терялось
        statusBoxBg = GradientDrawable()
        statusBoxBg.cornerRadius = 24f * resources.displayMetrics.density
        statusBoxBg.setColor(currentStatusColor)
        statusBox.background = statusBoxBg

        setupPressAnimation(statusBox)

        // Строки со списком доменов создаём один раз при старте — так список
        // виден сразу при разворачивании, даже если проверка ни разу не запускалась
        whitelistRows = WHITELIST_DOMAINS.associateWith { createDomainRow(it, whitelistColumnContainer) }
        nonWhitelistRows = NON_WHITELIST_DOMAINS.associateWith { createDomainRow(it, nonWhitelistColumnContainer) }
        whitelistRows.values.forEach { it.second.visibility = View.GONE }
        nonWhitelistRows.values.forEach { it.second.visibility = View.GONE }

        // Сайт разработчика — гиперссылка, открывает браузер по тапу
        developerSiteLink.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://$DEVELOPER_SITE")))
        }

        val drawerLayout: DrawerLayout = findViewById(R.id.drawerLayout)
        val menuButton: TextView = findViewById(R.id.menuButton)
        menuButton.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        sitesContainer.visibility = View.GONE
        collapseToggle.setOnClickListener {
            setSitesExpanded(!sitesExpanded)
        }

        statusBox.setOnClickListener {
            if (isChecking) return@setOnClickListener
            try {
                if (isVpnActive()) {
                    animateStatusColor(COLOR_VPN)
                    statusWord.text = "Выключи VPN"
                } else {
                    // Если список был свёрнут — разворачиваем его параллельно с запуском проверки
                    if (!sitesExpanded) setSitesExpanded(true)
                    requestCellularAndRun()
                }
            } catch (e: Exception) {
                animateStatusColor(COLOR_NO_NETWORK)
                statusWord.text = "Ошибка: ${e.javaClass.simpleName}"
            }
        }

        setupSettingsPanel()
    }

    // Лёгкая анимация "нажатия" — кнопка чуть сжимается под пальцем и возвращается обратно
    private fun setupPressAnimation(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }
            false // не перехватываем клик — он обрабатывается отдельным OnClickListener
        }
    }

    // Плавный переход цвета прямоугольника статуса вместо мгновенной подмены
    private fun animateStatusColor(newColor: Int) {
        val animator = ValueAnimator.ofObject(ArgbEvaluator(), currentStatusColor, newColor)
        animator.duration = 300
        animator.addUpdateListener { statusBoxBg.setColor(it.animatedValue as Int) }
        animator.start()
        currentStatusColor = newColor
    }

    // Разворачивает/сворачивает плитку со списком сайтов анимацией высоты —
    // выглядит как будто список выезжает из-под заголовков
    private fun setSitesExpanded(expand: Boolean) {
        sitesExpanded = expand
        collapseToggle.text = if (expand) "▼" else "▶"

        if (expand) {
            sitesContainer.visibility = View.VISIBLE
            sitesContainer.measure(
                View.MeasureSpec.makeMeasureSpec((sitesContainer.parent as View).width, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.UNSPECIFIED
            )
            val targetHeight = sitesContainer.measuredHeight
            sitesContainer.layoutParams.height = 0
            sitesContainer.alpha = 0f
            sitesContainer.requestLayout()

            val animator = ValueAnimator.ofInt(0, targetHeight)
            animator.duration = 300
            animator.addUpdateListener {
                sitesContainer.layoutParams.height = it.animatedValue as Int
                sitesContainer.alpha = (it.animatedValue as Int).toFloat() / targetHeight
                sitesContainer.requestLayout()
            }
            animator.start()
        } else {
            val startHeight = sitesContainer.height
            val animator = ValueAnimator.ofInt(startHeight, 0)
            animator.duration = 300
            animator.addUpdateListener {
                sitesContainer.layoutParams.height = it.animatedValue as Int
                sitesContainer.alpha = (it.animatedValue as Int).toFloat() / startHeight.coerceAtLeast(1)
                sitesContainer.requestLayout()
            }
            animator.addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    sitesContainer.visibility = View.GONE
                    sitesContainer.layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT
                }
            })
            animator.start()
        }
    }

    // Заполняет и подключает панель настроек: интервал автообновления и время уведомлений
    private fun setupSettingsPanel() {
        val intervalGroup: RadioGroup = findViewById(R.id.intervalRadioGroup)
        val startHourSpinner: Spinner = findViewById(R.id.startHourSpinner)
        val endHourSpinner: Spinner = findViewById(R.id.endHourSpinner)
        val saveButton: Button = findViewById(R.id.saveSettingsButton)

        val hours = (0..23).map { it.toString() }
        val hourAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, hours)
        hourAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        startHourSpinner.adapter = hourAdapter
        endHourSpinner.adapter = hourAdapter

        val currentInterval = SettingsPrefs.getIntervalMinutes(this)
        val checkedId = when (currentInterval) {
            15 -> R.id.interval15
            20 -> R.id.interval20
            30 -> R.id.interval30
            45 -> R.id.interval45
            60 -> R.id.interval60
            else -> R.id.intervalOff
        }
        intervalGroup.check(checkedId)

        startHourSpinner.setSelection(SettingsPrefs.getStartHour(this))
        endHourSpinner.setSelection(SettingsPrefs.getEndHour(this))

        saveButton.setOnClickListener {
            val minutes = when (intervalGroup.checkedRadioButtonId) {
                R.id.interval15 -> 15
                R.id.interval20 -> 20
                R.id.interval30 -> 30
                R.id.interval45 -> 45
                R.id.interval60 -> 60
                else -> 0
            }
            val startHour = startHourSpinner.selectedItemPosition
            val endHour = endHourSpinner.selectedItemPosition

            SettingsPrefs.setIntervalMinutes(this, minutes)
            SettingsPrefs.setTimeWindow(this, startHour, endHour)
            Scheduler.apply(this, minutes)

            android.widget.Toast.makeText(this, "Настройки сохранены", android.widget.Toast.LENGTH_SHORT).show()
        }

        val statsButton: Button = findViewById(R.id.statsButton)
        statsButton.setOnClickListener {
            startActivity(Intent(this, StatisticsActivity::class.java))
        }
    }

    private fun setStatus(color: Int, word: String, showSpinner: Boolean = false) {
        animateStatusColor(color)
        statusWord.text = word
        progressSpinner.visibility = if (showSpinner) View.VISIBLE else View.GONE
    }

    private fun isVpnActive(): Boolean {
        connectivityManager.allNetworks.forEach { network ->
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            if (capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) {
                return true
            }
        }
        return false
    }

    // Пульсирующая анимация плашки трафика, пока идёт проверка — вместо
    // резкого появления финального значения
    private fun startTrafficPulse() {
        trafficText.text = "Трафик: считаем..."
        trafficPulseAnimator?.cancel()
        val animator = ValueAnimator.ofFloat(1f, 0.4f)
        animator.duration = 600
        animator.repeatMode = ValueAnimator.REVERSE
        animator.repeatCount = ValueAnimator.INFINITE
        animator.addUpdateListener { trafficText.alpha = it.animatedValue as Float }
        animator.start()
        trafficPulseAnimator = animator
    }

    private fun stopTrafficPulse() {
        trafficPulseAnimator?.cancel()
        trafficPulseAnimator = null
        trafficText.alpha = 1f
    }

    // Живой секундомер с шагом 0.1 сек, пока идёт проверка
    private fun startTimeTicker(startTime: Long) {
        stopTimeTicker()
        val ticker = object : Runnable {
            override fun run() {
                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                timeText.text = "Время проверки: ${"%.1f".format(elapsed)} сек"
                uiHandler.postDelayed(this, 100)
            }
        }
        timeTicker = ticker
        uiHandler.post(ticker)
    }

    private fun stopTimeTicker() {
        timeTicker?.let { uiHandler.removeCallbacks(it) }
        timeTicker = null
    }

    private fun requestCellularAndRun() {
        isChecking = true
        setStatus(COLOR_CHECKING, "Проверка", showSpinner = true)
        startTrafficPulse()
        resetRows()
        developerSiteSpinner.visibility = View.VISIBLE
        developerSiteStatus.text = ""
        cellularNetwork = null

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cellularNetwork = network
                runOnUiThread { runChecks(network) }
            }

            override fun onUnavailable() {
                runOnUiThread {
                    isChecking = false
                    stopTrafficPulse()
                    stopTimeTicker()
                    setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
                }
            }
        }

        connectivityManager.requestNetwork(request, callback)

        uiHandler.postDelayed({
            if (cellularNetwork == null) {
                isChecking = false
                stopTrafficPulse()
                stopTimeTicker()
                setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
            }
        }, 5000)
    }

    // Возвращает строки списка в исходное состояние "ожидание" перед новой проверкой
    private fun resetRows() {
        (whitelistRows.values + nonWhitelistRows.values).forEach { (_, spinner) ->
            spinner.visibility = View.VISIBLE
        }
        whitelistRows.forEach { (domain, row) -> row.first.text = domain }
        nonWhitelistRows.forEach { (domain, row) -> row.first.text = domain }
    }

    private fun createDomainRow(domain: String, container: LinearLayout): Pair<TextView, ProgressBar> {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val spinner = ProgressBar(this, null, android.R.attr.progressBarStyleSmall)
        val spinnerParams = LinearLayout.LayoutParams(dp(14), dp(14))
        spinnerParams.marginEnd = dp(6)
        spinner.layoutParams = spinnerParams

        val label = TextView(this)
        label.text = domain
        label.textSize = 12f
        label.setTextColor(0xFFEEEEEE.toInt())
        label.typeface = android.graphics.Typeface.MONOSPACE

        row.addView(spinner)
        row.addView(label)
        container.addView(row)

        return Pair(label, spinner)
    }

    private fun updateRow(row: Pair<TextView, ProgressBar>, result: CheckResult) {
        row.second.visibility = View.GONE
        row.first.text = "${Checker.statusLabel(result)} ${result.domain}"
    }

    private fun runChecks(network: Network) {
        setStatus(COLOR_CHECKING, "Проверка", showSpinner = true)

        val startTime = System.currentTimeMillis()
        startTimeTicker(startTime)
        val uid = Process.myUid()
        val rxBefore = TrafficStats.getUidRxBytes(uid)
        val txBefore = TrafficStats.getUidTxBytes(uid)

        val totalTasks = WHITELIST_DOMAINS.size + NON_WHITELIST_DOMAINS.size + 1
        val completedCount = AtomicInteger(0)
        val whitelistResultsMap = ConcurrentHashMap<String, CheckResult>()
        val nonWhitelistResultsMap = ConcurrentHashMap<String, CheckResult>()
        val developerResultHolder = ConcurrentHashMap<String, CheckResult>()

        fun maybeFinish() {
            if (completedCount.incrementAndGet() == totalTasks) {
                val rxAfter = TrafficStats.getUidRxBytes(uid)
                val txAfter = TrafficStats.getUidTxBytes(uid)
                val elapsedMs = System.currentTimeMillis() - startTime

                val trafficBytes: Long? = if (rxBefore < 0 || txBefore < 0 || rxAfter < 0 || txAfter < 0) {
                    null
                } else {
                    (rxAfter - rxBefore) + (txAfter - txBefore)
                }

                val whitelistResults = WHITELIST_DOMAINS.map { whitelistResultsMap[it]!! }
                val nonWhitelistResults = NON_WHITELIST_DOMAINS.map { nonWhitelistResultsMap[it]!! }
                val developerResult = developerResultHolder[DEVELOPER_SITE]!!

                runOnUiThread {
                    isChecking = false
                    finalizeVerdict(whitelistResults, nonWhitelistResults, trafficBytes, elapsedMs, developerResult)
                }
            }
        }

        WHITELIST_DOMAINS.forEach { domain ->
            executor.submit {
                val result = Checker.checkDomain(network, domain)
                whitelistResultsMap[domain] = result
                runOnUiThread { updateRow(whitelistRows[domain]!!, result) }
                maybeFinish()
            }
        }

        NON_WHITELIST_DOMAINS.forEach { domain ->
            executor.submit {
                val result = Checker.checkDomain(network, domain)
                nonWhitelistResultsMap[domain] = result
                runOnUiThread { updateRow(nonWhitelistRows[domain]!!, result) }
                maybeFinish()
            }
        }

        executor.submit {
            val result = Checker.checkDomain(network, DEVELOPER_SITE)
            developerResultHolder[DEVELOPER_SITE] = result
            runOnUiThread {
                developerSiteSpinner.visibility = View.GONE
                developerSiteStatus.text = Checker.statusLabel(result)
            }
            maybeFinish()
        }
    }

    private fun finalizeVerdict(
        whitelistResults: List<CheckResult>,
        nonWhitelistResults: List<CheckResult>,
        trafficBytes: Long?,
        elapsedMs: Long,
        developerResult: CheckResult
    ) {
        stopTrafficPulse()
        stopTimeTicker()

        trafficText.text = if (trafficBytes != null) {
            val kb = trafficBytes / 1024.0
            if (kb < 1024) {
                "Потрачено трафика: ${"%.1f".format(kb)} КБ"
            } else {
                "Потрачено трафика: ${"%.2f".format(kb / 1024.0)} МБ"
            }
        } else {
            "Потрачено трафика: недоступно на этом устройстве"
        }

        timeText.text = "Время проверки: ${"%.1f".format(elapsedMs / 1000.0)} сек"

        val verdict = Checker.determineStatus(whitelistResults, nonWhitelistResults)
        val whitelistReachable = whitelistResults.count { it.reachable }
        val nonWhitelistReachable = nonWhitelistResults.count { it.reachable }
        Thread {
            HistoryStore(this).record(whitelistReachable, nonWhitelistReachable, verdict)
        }.start()

        when (verdict) {
            "unavailable" -> setStatus(COLOR_NO_NETWORK, "Нет доступа к сети")
            "on" -> setStatus(COLOR_ON, "Включены")
            else -> setStatus(COLOR_OFF, "Выключены")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
        stopTrafficPulse()
        stopTimeTicker()
    }
}
