package com.konstantin.whitelistchecker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Calendar

enum class ChartMode { DAY, WEEK }

class ChartView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    var mode: ChartMode = ChartMode.DAY
    private var dayPoints: List<Pair<Int, String>> = emptyList() // индекс = час 0..23, значение = кол-во доступных, статус
    private var weekBars: List<Triple<Int, String, Int>> = emptyList() // (мин.значение, статус мин, макс.значение) — статус макс считаем отдельно
    private var weekMaxStatuses: List<String> = emptyList()
    private val maxY = WHITELIST_DOMAINS.size + NON_WHITELIST_DOMAINS.size

    private val axisPaint = Paint().apply {
        color = 0xFF888888.toInt()
        strokeWidth = 2f
        textSize = 24f
    }
    private val linePaint = Paint().apply {
        strokeWidth = 6f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    private val barPaintRed = Paint().apply { color = 0xFFE53935.toInt() }
    private val barPaintGreen = Paint().apply { color = 0xFF43A047.toInt() }
    private val barPaintGrey = Paint().apply { color = 0xFF555555.toInt() }

    private fun colorFor(status: String): Int = when (status) {
        "on" -> 0xFFE53935.toInt()
        "off" -> 0xFF43A047.toInt()
        else -> 0xFF555555.toInt()
    }

    fun setDayData(hourToValue: Map<Int, Pair<Int, String>>) {
        // Заполняем все 24 часа: если данных на час нет — переносим предыдущее
        // известное значение, чтобы линия была непрерывной, а не рвалась
        var lastKnown: Pair<Int, String>? = null
        val filled = mutableListOf<Pair<Int, String>>()
        for (hour in 0..23) {
            val point = hourToValue[hour] ?: lastKnown
            if (point != null) {
                filled.add(point)
                lastKnown = point
            } else {
                filled.add(Pair(-1, "none")) // ещё нет данных вообще
            }
        }
        dayPoints = filled
        mode = ChartMode.DAY
        invalidate()
    }

    fun setWeekData(days: List<List<HistoryRecord>>) {
        // days[0] = понедельник ... days[6] = воскресенье
        val bars = mutableListOf<Triple<Int, String, Int>>()
        val maxStatuses = mutableListOf<String>()
        days.forEach { records ->
            if (records.isEmpty()) {
                bars.add(Triple(0, "none", 0))
                maxStatuses.add("none")
            } else {
                val totals = records.map { it.whitelistReachable + it.nonWhitelistReachable to it.status }
                val min = totals.minByOrNull { it.first }!!
                val max = totals.maxByOrNull { it.first }!!
                bars.add(Triple(min.first, min.second, max.first))
                maxStatuses.add(max.second)
            }
        }
        weekBars = bars
        weekMaxStatuses = maxStatuses
        mode = ChartMode.WEEK
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val paddingLeft = 60f
        val paddingBottom = 50f
        val paddingTop = 20f
        val chartW = w - paddingLeft - 20f
        val chartH = h - paddingBottom - paddingTop

        // Ось Y — подписи
        val steps = 4
        for (i in 0..steps) {
            val y = paddingTop + chartH - (chartH * i / steps)
            val value = (maxY * i / steps)
            canvas.drawText(value.toString(), 4f, y + 8f, axisPaint)
            canvas.drawLine(paddingLeft, y, w - 10f, y, axisPaint.apply { alpha = 60 })
            axisPaint.alpha = 255
        }

        if (mode == ChartMode.DAY) {
            drawDay(canvas, paddingLeft, paddingTop, chartW, chartH, h, paddingBottom)
        } else {
            drawWeek(canvas, paddingLeft, paddingTop, chartW, chartH, h, paddingBottom)
        }
    }

    private fun drawDay(canvas: Canvas, left: Float, top: Float, chartW: Float, chartH: Float, h: Float, paddingBottom: Float) {
        if (dayPoints.isEmpty()) return
        val stepX = chartW / 23f
        var prevX: Float? = null
        var prevY: Float? = null
        var prevStatus = "none"

        for (hour in 0..23) {
            val (value, status) = dayPoints[hour]
            val x = left + stepX * hour
            // Подписи часов через каждые 4
            if (hour % 4 == 0) {
                canvas.drawText(hour.toString(), x - 8f, h - 10f, axisPaint)
            }
            if (value < 0) {
                prevX = null
                prevY = null
                continue
            }
            val y = top + chartH - (chartH * value / maxY)
            if (prevX != null && prevY != null) {
                linePaint.color = colorFor(status)
                canvas.drawLine(prevX, prevY, x, y, linePaint)
            }
            prevX = x
            prevY = y
            prevStatus = status
        }
    }

    private fun drawWeek(canvas: Canvas, left: Float, top: Float, chartW: Float, chartH: Float, h: Float, paddingBottom: Float) {
        val dayLabels = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
        val groupWidth = chartW / 7f
        val barWidth = groupWidth * 0.32f

        for (i in 0 until 7) {
            if (i >= weekBars.size) break
            val (minValue, minStatus, maxValue) = weekBars[i]
            val maxStatus = weekMaxStatuses.getOrElse(i) { "none" }
            val groupLeft = left + groupWidth * i

            val minBarHeight = chartH * minValue / maxY
            val maxBarHeight = chartH * maxValue / maxY

            val minPaint = if (minStatus == "none") barPaintGrey else Paint(barPaintRed).apply { color = colorFor(minStatus) }
            val maxPaint = if (maxStatus == "none") barPaintGrey else Paint(barPaintGreen).apply { color = colorFor(maxStatus) }

            val bar1Left = groupLeft + groupWidth * 0.12f
            canvas.drawRect(bar1Left, top + chartH - minBarHeight, bar1Left + barWidth, top + chartH, minPaint)

            val bar2Left = groupLeft + groupWidth * 0.56f
            canvas.drawRect(bar2Left, top + chartH - maxBarHeight, bar2Left + barWidth, top + chartH, maxPaint)

            canvas.drawText(dayLabels[i], groupLeft + groupWidth * 0.3f, h - 10f, axisPaint)
        }
    }
}
