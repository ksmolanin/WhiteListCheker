package com.konstantin.whitelistchecker

import android.content.Context

// Простое хранилище настроек в SharedPreferences.
// intervalMinutes == 0 значит "автообновление выключено"
object SettingsPrefs {
    private const val PREFS_NAME = "whitelist_checker_settings"
    private const val KEY_INTERVAL_MINUTES = "interval_minutes"
    private const val KEY_START_HOUR = "start_hour"
    private const val KEY_END_HOUR = "end_hour"
    private const val KEY_LAST_STATUS = "last_status"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getIntervalMinutes(context: Context): Int =
        prefs(context).getInt(KEY_INTERVAL_MINUTES, 0)

    fun setIntervalMinutes(context: Context, minutes: Int) {
        prefs(context).edit().putInt(KEY_INTERVAL_MINUTES, minutes).apply()
    }

    fun getStartHour(context: Context): Int =
        prefs(context).getInt(KEY_START_HOUR, 7)

    fun getEndHour(context: Context): Int =
        prefs(context).getInt(KEY_END_HOUR, 21)

    fun setTimeWindow(context: Context, startHour: Int, endHour: Int) {
        prefs(context).edit()
            .putInt(KEY_START_HOUR, startHour)
            .putInt(KEY_END_HOUR, endHour)
            .apply()
    }

    fun getLastStatus(context: Context): String? =
        prefs(context).getString(KEY_LAST_STATUS, null)

    fun setLastStatus(context: Context, status: String) {
        prefs(context).edit().putString(KEY_LAST_STATUS, status).apply()
    }
}
