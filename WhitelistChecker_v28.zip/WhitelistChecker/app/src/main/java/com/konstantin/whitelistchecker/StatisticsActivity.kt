package com.konstantin.whitelistchecker

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import java.util.Calendar

class StatisticsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = 0xFF2A2A2A.toInt()

        val backButton: TextView = findViewById(R.id.backButton)
        backButton.setOnClickListener { finish() }

        val chartView: ChartView = findViewById(R.id.chartView)
        val dayButton = findViewById<android.widget.Button>(R.id.dayButton)
        val weekButton = findViewById<android.widget.Button>(R.id.weekButton)

        dayButton.setOnClickListener { loadDay(chartView) }
        weekButton.setOnClickListener { loadWeek(chartView) }

        loadDay(chartView)
    }

    private fun loadDay(chartView: ChartView) {
        Thread {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val startOfDay = cal.timeInMillis
            val endOfDay = startOfDay + 24 * 60 * 60 * 1000

            val records = HistoryStore(this).getRecordsBetween(startOfDay, endOfDay)
            // Для каждого часа берём последнюю запись в этом часе
            val hourMap = mutableMapOf<Int, Pair<Int, String>>()
            records.forEach { record ->
                val recordCal = Calendar.getInstance()
                recordCal.timeInMillis = record.timestamp
                val hour = recordCal.get(Calendar.HOUR_OF_DAY)
                hourMap[hour] = Pair(record.whitelistReachable + record.nonWhitelistReachable, record.status)
            }

            runOnUiThread { chartView.setDayData(hourMap) }
        }.start()
    }

    private fun loadWeek(chartView: ChartView) {
        Thread {
            val cal = Calendar.getInstance()
            cal.firstDayOfWeek = Calendar.MONDAY
            // Откатываемся к понедельнику текущей недели
            val currentDayOfWeek = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // 0 = понедельник
            cal.add(Calendar.DAY_OF_YEAR, -currentDayOfWeek)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)

            val store = HistoryStore(this)
            val days = mutableListOf<List<HistoryRecord>>()
            for (i in 0 until 7) {
                val dayStart = cal.timeInMillis
                val dayEnd = dayStart + 24 * 60 * 60 * 1000
                days.add(store.getRecordsBetween(dayStart, dayEnd))
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }

            runOnUiThread { chartView.setWeekData(days) }
        }.start()
    }
}
